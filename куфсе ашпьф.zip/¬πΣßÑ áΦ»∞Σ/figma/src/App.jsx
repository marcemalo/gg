import './App.css'
import Header from './components/Header'
import Hero from './components/Hero'
import Product from './components/Product'
import Iphome from './components/Iphome'
import Otziv from './components/Otziv'
import Footer from './components/Footer'

function App() {
  return (
    <>
      {Header()}
      {Hero()}
      {Product()}
      {Iphome()}
      {Otziv()}
      {Footer()}
    </>
  )
}

export default App
