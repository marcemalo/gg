import "./Otziv.css"
const Otziv = () => {
  return (
    <div className="big">
        <div className="container">


                              <div className="custo">
                                        <h1>What our customer say about this</h1>
                                        <img src="./src/img/Group 59.png" alt="" />
                              </div>


                              <div className="wraperrrrd">
                                <div className="cart">
                                    <img className="zx" src="./src/img/Frame 1116.png" alt="" />
                                    <p className="zx">“You made it so simple. My new site is so much faster and easier to work with than my old site. I just choose the page, make the change.”</p>
                                    <img className="zx" src="./src/img/Oval.png" alt="" />
                                </div>
                                <div className="cart">
                                    <img className="zx" src="./src/img/Frame 1116.png" alt="" />
                                    <p className="zx">“You made it so simple. My new site is so much faster and easier to work with than my old site. I just choose the page, make the change.”</p>
                                    <img className="zx" src="./src/img/Oval.png" alt="" />
                                </div>
                                <div className="cart">
                                    <img className="zx" src="./src/img/Frame 1116.png" alt="" />
                                    <p className="zx">“You made it so simple. My new site is so much faster and easier to work with than my old site. I just choose the page, make the change.”</p>
                                    <img className="zx" src="./src/img/Oval.png" alt="" />
                                </div>
                              </div>



        </div>
    </div>
  )
}

export default Otziv