

const Footer = () => {
  return (
    <div>
        <div className="container">
            <div className="wwwww">
                <img src="./src/img/Footer.png" alt="" />
            </div>
        </div>
    </div>
  )
}

export default Footer