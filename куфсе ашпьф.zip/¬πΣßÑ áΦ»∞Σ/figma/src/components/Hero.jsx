import "./Hero.css"

const Hero = () => {
  return (
    <div className="hero">
        <div className="container">
            <div className="hero__wrapper">
                <div className="hero__content">
                    <div><img src="./src/img/Group 51.png" alt="" /></div>
                    <div className="hero_cc">
                        <h1 className="l">Fastest<h1 className="o">Delivery</h1>& Esay<h1 className="o">Pickup.</h1></h1>
                        <p className="hh">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Imperdiet tempus felis vitae sit est quisque.</p>
                        <img className="hero_img" src="./src/img/Order Now.png" alt="" />
                    </div>
                </div>
                
                <div className="hero__img">
                    <img src="./src/img/Group 55.png" alt="" />
                </div>
            </div>
        </div>
    </div>
  )
}

export default Hero