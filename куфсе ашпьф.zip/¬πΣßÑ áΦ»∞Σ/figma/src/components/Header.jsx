import "./Header.css"
const Header = () => {
  return (
    <div className="header">
        <div className="container">
            <div className="header__wrapper">
                 <div>
                    <img src="./src/img/Frame 1109.svg" alt="" />
                 </div>
                 <div className="lo">
                    <ul className="class__list">
                          <li>Home</li>
                          <li>Service</li>
                          <li>Menu</li>
                          <li>Help</li>
                    </ul>
                 </div>
                 <div>
                    <img src="./src/img/Frame 1111.png" alt="" />
                 </div>
            </div>
        </div>
    </div>
  )
}

export default Header