import "./Product.css"
const Product = () => {
    
    const products = [
        {
            id: 1,
            name:'Burger',
            price: 1000,
            image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfGsPbMbWYi2MOQxN1hTNCzMnf_WugHIu0oQ&s'
        },
        {
            id: 2,
            name:'Burger',
            price: 1000,
            image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfGsPbMbWYi2MOQxN1hTNCzMnf_WugHIu0oQ&s'
        },
        {
            id: 3,
            name:'Burger',
            price: 1000,
            image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfGsPbMbWYi2MOQxN1hTNCzMnf_WugHIu0oQ&s'
        },
        {
            id: 4,
            name:'Burger',
            price: 1000,
            image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfGsPbMbWYi2MOQxN1hTNCzMnf_WugHIu0oQ&s'
        },
        {
            id: 5,
            name:'Burger',
            price: 1000,
            image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfGsPbMbWYi2MOQxN1hTNCzMnf_WugHIu0oQ&s'
        },
        {
            id: 6,
            name:'Burger',
            price: 1000,
            image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfGsPbMbWYi2MOQxN1hTNCzMnf_WugHIu0oQ&s'
        },
        

    ]
    




  return (
    <div>
        <div className="container">
            <h1 className="hw">Special Menu for you</h1>
            <div className="ww">
                   {
                    products.map(product => 
                        <div>
                            <img src={product.image} alt="" />
                            <h3>{product.name}</h3>
                            <strong>{product.price}</strong>
                        </div>
                    )
                   }
            </div>
        </div>
    </div>
  )
}

export default Product