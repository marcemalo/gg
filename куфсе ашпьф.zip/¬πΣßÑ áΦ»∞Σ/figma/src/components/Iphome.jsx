import "./Iphone.css"

const Iphome = () => {
  return (
    <div className="iphon">
        <div className="container">
            <div className="wrapperrrrrrrr">
                
                <img src="./src/img/Group 64.png" alt="" />
                <img src="./src/img/Group 63.png" alt="" />
            </div>
        </div>
    </div>
  )
}

export default Iphome